<?php $__env->startSection('content'); ?>  
<div class="row justify-content-center">
    <div class="form-group col-md-9">
        <div class="card">
            <div class="card-header" style="color:black">
                <h1>
                   Departamentos
                </h1>
            </div>
            <?php if(session('verifi')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('verifi')); ?>

                </div>
            <?php endif; ?>
            <div class="card-body" style="background-color: #DCDCDC">
                <div class="row float-left col-md-10">
                    <div class="form-group">
                        <div class="card">
                            <form class="form-inline" action="<?php echo e(url('/buscarDepartamento')); ?>" method="get">
                                <select class="form-control" id="seleccion" name="seleccion">
                                    <option value="id">
                                        Id
                                    </option>
                                    <option value="descripcion">
                                        Descripción
                                    </option>
                                </select>
                                <input class="form-control" id="search" name="search" type="text" ></input>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-search"></i>
                                </button>
                                <button method="get" action="<?php echo e(url('/IndexDepartamento')); ?>" class="btn btn-success">
                                    <i class="fas fa-sync-alt"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <a class="btn btn-primary float-left" data-target="#createDepartamento" data-toggle="modal" href="#" type="submit">
                    + Agregar
                </a>
                <div aria-hidden="true" aria-labelledby="exampleModalLabl" class="modal fade" id="createDepartamento" tabindex="-1">
                    <div class="modal-dialog modal-sm">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3 class="text-center text-muted" style="color:gray">
                                    Crear Nuevo Departamento
                                </h3>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route ('departamentos.store')); ?>" method="post">
                                    <?php echo e(csrf_field()); ?> <?php echo e(method_field('post')); ?>

                                <div class="form-group col-md-12">
                                    <input class="form-control" id="id" name="id" type="number" placeholder="Id" required>
                                    </input>
                                </div>
                                <div class="form-group col-md-12">
                                    <input class="form-control" id="descripcion" name="descripcion" type="text" placeholder="Descripción" required>
                                    </input>
                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-primary" type="submit">
                                        Guardar
                                    </button>
                                </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="table-responsive" style="width:100%;overflow:auto; max-height:430px;">
                    <table class="table table-dark ">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">
                                    Id
                                </th>
                                <th scope="col">
                                    Descripción
                                </th>
                                <th scope="col">
                                    Editar
                                </th>
                                <?php if(Auth::user()->role_id==2): ?>
                                <th scope="col">
                                    Eliminar
                                </th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                             <?php $__currentLoopData = $departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($departamento->status == 'activo'): ?>
                            <tr>
                                <th>
                                   <?php echo e($departamento->id); ?>

                                </th>

                                <td>
                                    <?php echo e($departamento->descripcion); ?>

                                </td>
                                <td>
                                    <?php if(Auth::user()->role_id==2): ?>
                                    <a class="btn btn-warning pull-right" data-target="#EditUsuario<?php echo e($departamento->id); ?>" data-toggle="modal" href="#" type="submit">
                                           <i class="fas fa-user-edit"></i>
                                            </i>
                                        </a>
                                        <div aria-hidden="true" aria-labelledby="exampleModalLabl" class="modal fade" id="EditUsuario<?php echo e($departamento->id); ?>" tabindex="-1">
                                            <div class="modal-dialog ">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title text-dark">
                                                            <?php echo e($departamento->descripcion); ?> 
                                                        </h5>
                                                        <button class="close" data-dismiss="modal" type="button">
                                                            <span>
                                                                ×
                                                            </span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body carta">
                                                        <form action="<?php echo e(route ('departamentos.update',$departamento->id)); ?>"  method="post">
                                                        <?php echo e(csrf_field()); ?> <?php echo e(method_field('put')); ?>

                                                            <div class="form-group">
                                                                <label class="control-label text-muted" for="id">
                                                                    Id
                                                                </label>
                                                                <label class="form-control" style="background-color: #85929E" id="id" name="id">
                                                                    <?php echo e($departamento->id); ?>

                                                                </label>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="control-label text-muted" for="nombre">
                                                                    Descripción
                                                                </label>
                                                                <input class="form-control" id="descripcion" name="descripcion" type="text" value="<?php echo e($departamento->descripcion); ?>">   
                                                                </input>
                                                            </div>
                                                            
                                                    <div class="modal-footer">
                                                        <button class="btn btn-primary" type="submit">
                                                            Guardar
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    </td>
                                </td>
                                <td>
                                    <?php if(Auth::user()->role_id==2): ?>
                                        <form action="<?php echo e(route ('departamentos.delete',$departamento->id)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <button class="btn btn-danger" onclick="return confirm('¿Borrar?');" type="submit">
                                                <i class="fas fa-user-times"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CEVI2.0\resources\views/Departamentos/IndexDepartamentos.blade.php ENDPATH**/ ?>