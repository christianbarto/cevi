<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="form-group col-md-9">
        <div class="card">
            <div class="card-header" style="color:black">
                <h1>
                   Registro de Incidencias
                </h1>
            </div>
            <div class="card-body" style="background-color: #DCDCDC">
                <div class="table-responsive" style="width:100%;overflow:auto; max-height:430px;">
                    <table class="table table-dark ">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">
                                    Fecha
                                </th>
                                <th scope="col">
                                    RFC
                                </th>
                                <th scope="col">
                                    Nombre
                                </th>
                                <th scope="col">
                                    Apellido Paterno
                                </th>
                                <th scope="col">
                                    Apellido Materno
                                </th>
                                <th scope="col">
                                    Incidencia
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $Relojs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Reloj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(strcmp(($Reloj->incidencia),'NORMAL')!== 0): ?>
                            <tr>
                                <td>
                                    <?php echo e(Date::parse($Reloj->fecha)->format('j \d\e F \d\e Y')); ?>

                                    
                                </td>
                                <td>
                                    <?php echo e($Reloj->RFC); ?>

                                </td>
                                <td>
                                    <?php echo e($Reloj->nombre); ?>

                                </td>
                                <td>
                                    <?php echo e($Reloj->ap_paterno); ?>

                                </td>
                                <td>
                                    <?php echo e($Reloj->ap_materno); ?>

                                </td>
                                <td>
                                    <?php echo e($Reloj->incidencia); ?>

                                </td>
                            
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row justify-content-center">
    <div class="form-group col-md-9">
        <div class="card">
            <div class="card-header" style="color:black">
                <h3>
                    Notificaciones
                </h3>
            </div>
            <div class="card-body" style="background-color: #DCDCDC">
                <div class="table-responsive" style="width:100%;overflow:auto; max-height:430px;">
                    <table class="table table-dark table-hover">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">
                                    RFC
                                </th>
                                <th scope="col">
                                    Nombre(s)
                                </th>
                                <th scope="col">
                                    Apellido Paterno
                                </th>
                                <th scope="col">
                                    Apellido Materno
                                </th>
                                <th scope="col">
                                    Quinquenios
                                </th>
                                <th scope="col">
                                    Proximo Quinquenio
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $Empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($Empleado->estatus=='activo'): ?>
                                    <?php if($Empleado->Tcontrato=='base' 
                                    || $Empleado->Tcontrato=='nombremientoConfianza'
                                    || $Empleado->Tcontrato=='mandosMedios'): ?>
                                        <?php if(!$Empleado->fecha_nombramiento==null): ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($Empleado->RFC); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($Empleado->nombre); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($Empleado->ap_paterno); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($Empleado->ap_materno); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($Empleado->quinquenio); ?>

                                                </td>
                                                <td>           
                                                    <?php if($Empleado->quinquenio<1): ?>
                                                        <?php echo e(Date::parse($Empleado->fecha_nombramiento->addYear(5))->format('j \d\e F \d\e Y')); ?>

                                                    <?php elseif($Empleado->quinquenio==1): ?>
                                                        <?php echo e(Date::parse($Empleado->fecha_nombramiento->addYear(10))->format('j \d\e F \d\e Y')); ?>

                                                    <?php elseif($Empleado->quinquenio==2): ?>
                                                        <?php echo e(Date::parse($Empleado->fecha_nombramiento->addYear(15))->format('j \d\e F \d\e Y')); ?>

                                                    <?php elseif($Empleado->quinquenio==3): ?>
                                                        <?php echo e(Date::parse($Empleado->fecha_nombramiento->addYear(20))->format('j \d\e F \d\e Y')); ?>

                                                    <?php elseif($Empleado->quinquenio==4): ?>
                                                        <?php echo e(Date::parse($Empleado->fecha_nombramiento->addYear(25))->format('j \d\e F \d\e Y')); ?>

                                                    <?php elseif($Empleado->quinquenio==5): ?>
                                                        <?php echo e(Date::parse($Empleado->fecha_nombramiento->addYear(30))->format('j \d\e F \d\e Y')); ?>

                                                    <?php elseif($Empleado->quinquenio==6): ?>
                                                        <?php echo e(Date::parse($Empleado->fecha_nombramiento->addYear(35))->format('j \d\e F \d\e Y')); ?>

                                                    <?php elseif($Empleado->quinquenio==7): ?>
                                                        <?php echo e(Date::parse($Empleado->fecha_nombramiento->addYear(40))->format('j \d\e F \d\e Y')); ?>

                                                    <?php elseif($Empleado->quinquenio==8): ?>
                                                        <?php echo e(Date::parse($Empleado->fecha_nombramiento->addYear(45))->format('j \d\e F \d\e Y')); ?>

                                                    <?php elseif($Empleado->quinquenio==9): ?>
                                                        <?php echo e(Date::parse($Empleado->fecha_nombramiento->addYear(50))->format('j \d\e F \d\e Y')); ?>

                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CEVI2.0\resources\views/HomeAdmin.blade.php ENDPATH**/ ?>