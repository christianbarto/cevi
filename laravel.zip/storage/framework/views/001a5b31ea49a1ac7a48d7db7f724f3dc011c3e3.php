<img height="90" src="img/CEVILOGO2020.jpg" width="428" style="margin-top:0px;"></img>
<h4 style="text-align: left;">
    Generado: <?php echo e(Date::parse(now())->format('j \d\e F \d\e Y')); ?><br>
    Usuario: <?php echo e(Auth::user()->name); ?>

</h4>
<h3>
    Usuarios Activos
</h3>
    <table border="1" align="center" cellspacing="0" cellpadding="1" style="text-align: center;">
        <thead class="thead-light">
            <tr>
                <th scope="col">
                    Nombre(s)
                </th>
                <th scope="col">
                    Apellido Paterno
                </th>
                <th scope="col">
                    Apellido Materno
                </th>
                <th scope="col">
                    Correo
                </th>
                <th scope="col">
                    Role
                </th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $User): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($User->name); ?>

                </td>
                <td>
                    <?php echo e($User->ap_paterno); ?>

                </td>
                <td>
                    <?php echo e($User->ap_materno); ?>

                </td>
                <td>
                    <?php echo e($User->email); ?>

                </td>
                <td>
                    <?php if(($User->role_id) > 1): ?>
                                    Administrador
                                <?php else: ?>
                                    Usuario
                                <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\CEVI2.0\resources\views/pdf/IndexUser.blade.php ENDPATH**/ ?>