<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="container" id="mycontainer">
        <div class="row justify-content-center">
            <div class="col-md-8 logo-dep" style="background-color: #D5DBDB">
                <div class="img">
                    <img class="img-fluid" src="img/cevi2.png" width="30%">
                    </img>
                </div>
                <form action="<?php echo e(route('login')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label class="col-md-4 col-form-label text-md-right" for="email">
                            <?php echo e(""); ?>

                        </label>
                        <div class="col-md-4">
                            <input autocomplete="off"  style="background-color: #F2F4F4 " autofocus="" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="entrada_text" name="email" type="text" value="<?php echo e(old('email')); ?>" placeholder="Direccion de Correo">
                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong>
                                        Usuario invalido
                                    </strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </input>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-4 col-form-label text-md-right" for="password">
                            <?php echo e(""); ?>

                        </label>
                        <div class="col-md-4">
                            <input autocomplete="current-password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" style="background-color: #F2F4F4 " id="password" name="password" required="" type="password" placeholder="Contraseña">
                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong>
                                        <?php echo e($message); ?>

                                    </strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </input>
                        </div>
                        <div class="col-md-10" style="margin-top: 8px;">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                    <label class="form-check-label" for="remember" style="color: black;">
                                        <h6>Recordarme</h6>
                                    </label>
                                </div>
                        </div>

                    </div>
                    <div class="form-group" align="center">
                        <button class="btn btn-primary" type="submit">
                            <?php echo e(__('Login')); ?>

                        </button>
                    </div>

                        <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                        ¿Olviaste tu Contraseña?
                        </a>
                    <br>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CEVI2.0\resources\views/auth/login.blade.php ENDPATH**/ ?>