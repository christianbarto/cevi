<?php $__env->startSection('content'); ?>
<div class="container-fluid"  style="background-color:#7D3C98">
  <h1>Nuevo Usuario</h1>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CEVI2.0\resources\views/Empleados/IndexEmpleados.blade.php ENDPATH**/ ?>