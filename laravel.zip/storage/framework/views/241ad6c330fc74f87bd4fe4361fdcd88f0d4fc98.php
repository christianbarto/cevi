<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
            <meta content="width=device-width,user-scalable=no, initial-scale=1, maximum-scale=1.0" name="viewport">
                <!-- CSRF Token -->
                <meta content="<?php echo e(csrf_token()); ?>" name="csrf-token">
                    <title>
                        <?php echo e('CEVI'); ?>

                    </title>
                    <!-- Scripts -->
                    <script defer="" src="<?php echo e(asset('js/app.js')); ?>">
                    </script>
                    <script type="text/javascript" src="<?php echo e(asset('js/desabilitar.js')); ?>">
                    </script>
                    <script crossorigin="anonymous" src="https://kit.fontawesome.com/afca8b434b.js">
                    </script>
                    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
                    <!-- Fonts -->
                    <link href="//fonts.gstatic.com" rel="dns-prefetch"/>
                    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet"/>
                    <!-- Styles -->
                    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet"/>
                    <link href="<?php echo e(asset('css/estilos.css')); ?>" rel="stylesheet"/>
    </head>
    <style>
        body{
                background-image: url(img/fondo.png);
                background-color: rgba(0,0,0,0.6);
                background-size: 4000px;
                text-align: center;
                background-position: center center;
                background-size: cover;
                background-repeat: repeat-x;
                position: relative;
            }
    </style>
    <body>
        <div class="row">
            <img alt="Comisión Estatal de Vivienda" class="img-fluid" height="100" src="img/texturaSuperior.png" width="1566">
            </img>
        </div>
            <nav class="navbar navbar-expand-md navbar-dark bg-dark shadow-sm "> 
                <div class="container-fluid d-flex justify-content-around">
                    <?php if(Auth::user()->role_id==2): ?>
                    <a class="navbar-brand navbar-collapse bg-dark" href="<?php echo e(route('home')); ?>">
                        Bienvenido Administrador
                    </a>
                    <?php else: ?>
                    <a class="navbar-brand navbar-collapse bg-dark" href="<?php echo e(route('home')); ?>">
                        Bienvenido
                    </a>
                    <?php endif; ?>
                    <div class="navbar-nav ">
                        <ul class="navbar-nav ">
                            <li class="nav-item">
                                <a class="nav-link active" href="<?php echo e(route('home')); ?>">
                                    Inicio
                                </a>
                            </li>
                            <?php if(Auth::user()->role_id==2): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('usuarios')); ?>">
                                    Usuarios
                                </a>
                            </li>
                            <?php endif; ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('empleados.index')); ?>">
                                    Empleados
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('/IndexDepartamento')); ?>">
                                    Departamentos
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('/IndexCategorias')); ?>">
                                    Categorias
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('checador.index')); ?>">
                                    Reloj
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('reportes.index')); ?>">
                                    Reportes
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="navbar-collapse">
                        <!-- Right Side Of Navbar -->
                        <ul class="navbar-nav ml-auto">
                            <!-- Authentication Links -->
                            <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <label class="alert-danger" for="">
                                    Su Sesion ha caducado
                                </label>
                                <a class="nav-link" href="<?php echo e(route('login')); ?>">
                                    <?php echo e(__('Login')); ?>

                                </a>
                            </li>
                            <?php else: ?>
                            <li class="nav-item dropdown">
                                <a aria-expanded="false" aria-haspopup="true" class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" id="navbarDropdown" role="button" v-pre="">
                                    <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->ap_paterno); ?> <?php echo e(Auth::user()->ap_materno); ?>

                                    <span class="caret">
                                    </span>
                                </a>
                                <div aria-labelledby="navbarDropdown" class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                         document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>
                                    <form action="<?php echo e(route('logout')); ?>" id="logout-form" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </nav>
        <main class="py-3">
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\CEVI2.0\resources\views/layouts/app2.blade.php ENDPATH**/ ?>