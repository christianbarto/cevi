<?php $__env->startSection('content'); ?>
<div class="row justify-content-center overflow-auto">
    <div class="form-group col-md-9">
            <div class="card">
                <div class="card-header">
                    <h1 style="color: black">
                        <?php echo e($empleados->nombre); ?> <?php echo e($empleados->ap_paterno); ?> <?php echo e($empleados->ap_materno); ?>

                    </h1>
                </div>
                <div class="card-body" style="background-color: #DCDCDC">
                    <form action="<?php echo e(route ('empleado.update',$empleados->id)); ?>"  enctype="multipart/form-data" method="post">
                                                        <?php echo e(csrf_field()); ?> <?php echo e(method_field('put')); ?>

                        <div class="form-group col-md-5  text-muted ">
                            <h2>
                                Editar Datos
                            </h2>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="id">
                                    Numero de Trabajador
                                </label>
                                <input class="form-control"  value="<?php echo e($empleados->id); ?>" name="id" type="text" disabled>
                                </input>
                            </div>
                                <?php if(Auth::user()->role_id==2): ?>
                                    <div class="form-group col-md-3">
                                        <label class="control-label text-muted" for="nombre">
                                            Nombre
                                        </label>
                                        <input class="form-control" id="nombre" name="nombre" type="text" value="<?php echo e($empleados->nombre); ?>">
                                        </input>
                                    </div>
                                    <div class="form-group col-md-3">
                                        <label class="control-label text-muted" for="ap_paterno">
                                            Apellido Paterno
                                        </label>
                                        <input class="form-control" id="ap_paterno" name="ap_paterno" type="text" value="<?php echo e($empleados->ap_paterno); ?>">
                                        </input>
                                    </div>
                                    <div class="form-group col-md-3">
                                        <label class="control-label text-muted" for="ap_materno">
                                            Apellido Materno
                                        </label>
                                        <input class="form-control" id="ap_materno" name="ap_materno" type="text" value="<?php echo e($empleados->ap_materno); ?>">
                                        </input>
                                    </div>
                                <?php endif; ?>
                                <?php if(Auth::user()->role_id==1): ?>
                                    <div class="form-group col-md-3">
                                        <label class="control-label text-muted" for="nombre">
                                            Nombre
                                        </label>
                                        <input disabled class="form-control" id="nombre" name="nombre" type="text" value="<?php echo e($empleados->nombre); ?>">
                                        </input>
                                    </div>
                                    <div class="form-group col-md-3">
                                        <label class="control-label text-muted" for="ap_paterno">
                                            Apellido Paterno
                                        </label>
                                        <input disabled class="form-control" id="ap_paterno" name="ap_paterno" type="text" value="<?php echo e($empleados->ap_paterno); ?>">
                                        </input>
                                    </div>
                                    <div class="form-group col-md-3">
                                        <label class="control-label text-muted" for="ap_materno">
                                            Apellido Materno
                                        </label>
                                        <input disabled class="form-control" id="ap_materno" name="ap_materno" type="text" value="<?php echo e($empleados->ap_materno); ?>">
                                        </input>
                                    </div>
                                <?php endif; ?>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="fecha_alta">
                                    Alta : 
                                </label>
                                <label class="control-label text-muted" for="fecha_alta">
                                    <?php echo e(Date::parse($empleados->fecha_alta)->format('j \d\e F \d\e Y')); ?>

                                </label>
                                <input class="form-control" id="fecha_alta" name="fecha_alta" type="date" min="1980-01-01" value=<?php echo e($empleados->fecha_alta); ?>  max=<?php echo e(now()); ?>>
                                </input>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="Tcontrato">
                                    Relacion Laboral:
                                </label>
                                <label class="form-label text-muted">
                                    <?php if($empleados->Tcontrato=='base'): ?>
                                        PERSONAL DE BASE
                                    <?php elseif($empleados->Tcontrato=='contrato'): ?>
                                        PERSONAL DE CONTRATO
                                    <?php elseif($empleados->Tcontrato=='nombremientoConfianza'): ?>
                                        NOMBRAMIENTO CONFIANZA
                                    <?php elseif($empleados->Tcontrato=='mandosMedios'): ?>
                                        MANDOS MEDIOS
                                    <?php elseif($empleados->Tcontrato=='contratoConfianza'): ?>
                                        CONTRATO CONFIANZA
                                    <?php endif; ?>                                    
                                </label>
                                <select onChange="prueba()" class="form-control" id="Tcontrato" name="Tcontrato">
                                    <option value="">
                                        Seleccione una opción
                                    </option>
                                    <option value="base">
                                        PERSONAL DE BASE
                                    </option>
                                    <option value="contrato">
                                        PERSONAL DE CONTRATO
                                    </option>
                                    <option value="nombremientoConfianza">
                                        NOMBRAMIENTO CONFIANZA
                                    </option>
                                    <option value="mandosMedios">
                                        MANDOS MEDIOS
                                    </option>
                                    <option value="contratoConfianza">
                                        CONTRATO CONFIANZA
                                    </option>
                                </select>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" >
                                    Nombramiento:
                                </label>
                                    <label class="control-label text-muted">                                                                        
                                        <?php if($empleados->fecha_nombramiento==null): ?>
                                        <?php else: ?>
                                            <?php echo e(Date::parse($empleados->fecha_nombramiento)->format('j \d\e F \d\e Y')); ?>

                                        <?php endif; ?>
                                    </label>
                                    <input  disabled class="form-control" id="fecha_nombramiento" name="fecha_nombramiento" type="date" min="1980-01-01" max=<?php echo e(now()); ?> value=<?php echo e($empleados->fecha_nombramiento); ?>>
                                    </input>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="RFC">
                                    RFC
                                </label>
                                <input style="text-transform:uppercase;" class="form-control" id="RFC" name="RFC" type="text" value="<?php echo e($empleados->RFC); ?>" maxlength="13">
                                </input>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="telefono">
                                    Telefono
                                </label>
                                <input class="form-control" id="telefono" name="telefono" type="number" value="<?php echo e($empleados->telefono); ?>" min="0" max="9999999999">
                                </input>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="genero">
                                    Genero: <?php echo e($empleados->genero); ?>

                                </label>
                                <select class="form-control" id="genero" name="genero">
                                    <option value="">
                                        Seleccione una opción
                                    </option>
                                    <option value="Hombre">
                                        Hombre
                                    </option>
                                    <option value="Mujer">
                                        Mujer
                                    </option>
                                </select>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="correo">
                                    Correo
                                </label>
                                <input class="form-control" id="correo" name="correo" type="text" value="<?php echo e($empleados->correo); ?>">
                                </input>
                                </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="puesto">
                                    Categoria: <?php echo e($empleados->puesto); ?>

                                </label>
                                <select class="form-control" id="puesto" name="puesto" value="<?php echo e($empleados->puesto); ?>">
                                    <option value="">Seleccione una opción</option>                                   <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($categoria->descripcion); ?>">
                                            <?php echo e($categoria->identificador); ?>---<?php echo e($categoria->descripcion); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="departamento">
                                    Departamento: <?php echo e($empleados->departamento); ?>

                                </label>
                                <select class="form-control" id="departamento" name="departamento">
                                    <option value="">
                                            Seleccione una opción
                                    </option>
                                    <?php $__currentLoopData = $departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($departamento->descripcion); ?>">
                                            <?php echo e($departamento->id); ?> <?php echo e($departamento->descripcion); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group col-md-5  text-muted ">
                            <h2>
                                Editar Documentos 
                            </h2>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-4">
                                <div class="text-dark">
                                    <?php if($empleados->contrato==null): ?>
                                        <label class="control-label text-muted" for="contrato">
                                        Ingresar Contrato  
                                        </label>
                                    <?php else: ?>
                                        <label class="control-label text-muted" for="contrato">
                                        Actualizar Contrato
                                        </label>
                                    <?php endif; ?>
                                    <input style="width: 92%" accept="application/pdf" name="contrato" type="file">
                                        <label for="contrato">
                                        </label>
                                    </input>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="text-dark">
                                    <?php if($empleados->creden_elect==null): ?>
                                        <label class="control-label text-muted" for="creden_elect">
                                        Ingresar Credencial de Elector    
                                        </label>
                                    <?php else: ?>
                                        <label class="control-label text-muted" for="creden_elect">
                                        Actualizar Credencial de Elector        
                                        </label>
                                    <?php endif; ?>
                                    <input style="width: 92%" accept="application/pdf" name="creden_elect" type="file">
                                    <label for="creden_elect">
                                    </label>
                                    </input>
                                    </div>
                                </div>
                            <div class="form-group col-md-4">
                                <div class="text-dark">
                                    <?php if($empleados->acta_nac==null): ?>
                                        <label class="control-label text-muted" for="acta_nac">
                                        Ingresar Acta de Nacimiento 
                                        </label>
                                    <?php else: ?>
                                        <label class="control-label text-muted" for="acta_nac">
                                        Actualizar Acta de Nacimiento
                                        </label>
                                    <?php endif; ?>
                                    <input style="width: 92%" accept="application/pdf" name="acta_nac" type="file">
                                    <label for="acta_nac">
                                    </label>
                                    </input>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="text-dark">
                                    <?php if($empleados->curriculum==null): ?>
                                        <label class="control-label text-muted" for="curriculum">
                                            Ingresar Curriculum
                                        </label>
                                    <?php else: ?>
                                        <label class="control-label text-muted" for="curriculum">
                                            Actualizar Curriculum
                                        </label>
                                    <?php endif; ?>
                                    <input style="width: 92%" accept="application/pdf" name="curriculum" type="file">
                                    <label for="curriculum">
                                    </label>
                                    </input>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                                            <div class="text-dark">
                                                                <?php if($empleados->solicitud==null): ?>
                                                                    <label class="control-label text-muted" for="solicitud">
                                                                       ----Ingresar Solicitud de Empleo-----
                                                                    </label>
                                                                <?php else: ?>
                                                                    <label class="control-label text-muted" for="solicitud">
                                                                       ---Actualizar Solicitud de Empleo----
                                                                    </label>
                                                                <?php endif; ?>
                                                                <input style="width: 92%" accept="application/pdf" name="solicitud" type="file">
                                                                    <label for="solicitud">
                                                                    </label>
                                                                </input>
                                                            </div>
                                                        </div>
                                                        <br>
                                                        <div class="form-group col-md-4">
                                                            <div class="text-dark">
                                                                <?php if($empleados->cert_medico==null): ?>
                                                                    <label class="control-label text-muted" for="cert_medico">
                                                                       -----Ingresar Certificado Medico-----
                                                                    </label>
                                                                <?php else: ?>
                                                                    <label class="control-label text-muted" for="cert_medico">
                                                                       ----Actualizar Certificado Medico----
                                                                    </label>
                                                                <?php endif; ?>
                                                                <input style="width: 92%" accept="application/pdf" name="cert_medico" type="file">
                                                                    <label for="cert_medico">
                                                                    </label>
                                                                </input>
                                                            </div>
                                                        </div>
                                                        <br>
                                                        <div class="form-group col-md-4">
                                                            <div class="text-dark">
                                                                <?php if($empleados->cart_recomend==null): ?>
                                                                    <label class="control-label text-muted" for="cart_recomend">
                                                                       ---Ingresar Carta de Recomendacion---  
                                                                    </label>
                                                                <?php else: ?>
                                                                    <label class="control-label text-muted" for="cart_recomend">
                                                                       --Actualizar Carta de Recomendacion--
                                                                    </label>
                                                                <?php endif; ?>
                                                                <input style="width: 92%" accept="application/pdf" name="cart_recomend" type="file">
                                                                    <label for="cart_recomend">
                                                                    </label>
                                                                </input>
                                                            </div>
                                                        </div>
                                                        <br>
                                                        <div class="form-group col-md-4">
                                                            <div class="text-dark">
                                                                <?php if($empleados->fotografia==null): ?>
                                                                    <label class="control-label text-muted" for="fotografia">
                                                                       ---------Ingresar Fotografia---------  
                                                                    </label>
                                                                <?php else: ?>
                                                                    <label class="control-label text-muted" for="fotografia">
                                                                       --------Actualizar Fotografia--------
                                                                    </label>
                                                                <?php endif; ?>
                                                                <input style="width: 92%" accept="application/pdf" name="fotografia" type="file">
                                                                    <label for="fotografia">
                                                                    </label>
                                                                </input>
                                                            </div>
                                                        </div>
                                                        <br>
                                                        <div class="form-group col-md-4">
                                                            <div class="text-dark">
                                                                <?php if($empleados->const_Noinhab==null): ?>
                                                                    <label class="control-label text-muted" for="const_Noinhab">
                                                                       Ingresar Constancia No Inhabilitacion  
                                                                    </label>
                                                                <?php else: ?>
                                                                    <label class="control-label text-muted" for="const_Noinhab">
                                                                     Actualizar Constancia No Inhabilitacion
                                                                    </label>
                                                                <?php endif; ?>

                                                                <input style="width: 92%" accept="application/pdf" name="const_Noinhab" type="file">
                                                                    <label for="const_Noinhab">
                                                                    </label>
                                                                </input>
                                                            </div>
                                                        </div>
                                                        <br>
                                                        <div class="form-group col-md-4">
                                                            <div class="text-dark">
                                                                <?php if($empleados->comp_Dom==null): ?>
                                                                    <label class="control-label text-muted" for="comp_Dom">
                                                                       --Ingresar Comprobante de Domicilio--  
                                                                    </label>
                                                                <?php else: ?>
                                                                    <label class="control-label text-muted" for="comp_Dom">
                                                                       -Actualizar Comprobante de Domicilio-
                                                                    </label>
                                                                <?php endif; ?>

                                                                <input style="width: 92%" accept="application/pdf" name="comp_Dom" type="file">
                                                                    <label for="comp_Dom">
                                                                    </label>
                                                                </input>
                                                            </div>
                                                        </div>
                                                        <br>
                                                        <div class="form-group col-md-4">
                                                            <div class="text-dark">
                                                                <?php if($empleados->licencia==null): ?>
                                                                    <label class="control-label text-muted" for="licencia">
                                                                       ----Ingresar Licencia de Conducir----
                                                                    </label>
                                                                <?php else: ?>
                                                                    <label class="control-label text-muted" for="licencia">
                                                                       ---Actualizar Licencia de Conducir---
                                                                    </label>
                                                                <?php endif; ?>

                                                                <input style="width: 92%" accept="application/pdf" name="licencia" type="file">
                                                                    <label for="licencia">
                                                                    </label>
                                                                </input>
                                                            </div>
                                                        </div>
                                                        <br>
                                                        <div class="form-group col-md-4 text-dark">
                                                                <?php if($empleados->nss==null): ?>
                                                                    <label class="control-label text-muted" for="nss">
                                                                       ---Ingresar Numero de Seguro Social--
                                                                    </label>
                                                                <?php else: ?>
                                                                    <label class="control-label text-muted" for="nss">
                                                                       --Actualizar Numero de Seguro Social--
                                                                    </label>
                                                                <?php endif; ?>
                                                                <input style="width: 92%" accept="application/pdf" name="nss" type="file">
                                                                    <label for="nss">
                                                                    </label>
                                                                </input>
                                                        </div>
                                                        <br>
                                                        <div class="form-group col-md-4">
                                                            <div class="text-dark">
                                                                <?php if($empleados->infonavit==null): ?>
                                                                    <label class="control-label text-muted" for="infonavit">
                                                                       ---------Ingresar Infonavit----------
                                                                    </label>
                                                                <?php else: ?>
                                                                    <label class="control-label text-muted" for="infonavit">
                                                                       --------Actualizar Infonavit---------
                                                                    </label>
                                                                <?php endif; ?>
                                                                <input style="width: 92%" accept="application/pdf" name="infonavit" type="file">
                                                                    <label for="infonavit">
                                                                    </label>
                                                                </input>
                                                            </div>
                                                        </div>
                                                        <br>
                                                        <div class="form-group col-md-4">
                                                            <div class="text-dark">
                                                                <?php if($empleados->rfc_doc==null): ?>
                                                                    <label class="control-label text-muted" for="rfc_doc">
                                                                       -----Ingresar Comprobante de RFC-----
                                                                    </label>
                                                                <?php else: ?>
                                                                    <label class="control-label text-muted" for="rfc_doc">
                                                                       ----Actualizar Comprobante de RFC----
                                                                    </label>
                                                                <?php endif; ?>
                                                                <input style="width: 92%" accept="application/pdf" name="rfc_doc" type="file">
                                                                    <label for="rfc_doc">
                                                                    </label>
                                                                </input>
                                                            </div>
                                                        </div>
                                                        <br>
                                                        <div class="form-group col-md-4">
                                                            <div class="text-dark">
                                                                <?php if($empleados->cartilla==null): ?>
                                                                    <label class="control-label text-muted" for="cartilla">
                                                                       --Ingresar Cartilla Militar Liberada--
                                                                    </label>
                                                                <?php else: ?>
                                                                    <label class="control-label text-muted" for="cartilla">
                                                                       -Actualizar Cartilla Militar Liberada-
                                                                    </label>
                                                                <?php endif; ?>
                                                                <input style="width: 92%" accept="application/pdf" name="cartilla" type="file">
                                                                    <label for="cartilla">
                                                                    </label>
                                                                </input>
                                                            </div>
                                                        </div>
                                                        <br>
                                                        <div class="form-group col-md-4">
                                                            <div class="text-dark">
                                                                <?php if($empleados->curp==null): ?>
                                                                    <label class="control-label text-muted" for="curp">
                                                                       ----Ingresar Comprobante de CURP-----
                                                                    </label>
                                                                <?php else: ?>
                                                                    <label class="control-label text-muted" for="curp">
                                                                       ---Actualizar Comprobante de CURP----
                                                                    </label>
                                                                <?php endif; ?>
                                                                <input style="width: 92%" accept="application/pdf" name="curp" type="file">
                                                                    <label for="curp">
                                                                    </label>
                                                                </input>
                                                            </div>
                                                        </div>
                                                        <br>
                                                        <div class="form-group col-md-4">
                                                            <div class="text-dark">
                                                                <?php if($empleados->diploma==null): ?>
                                                                    <label class="control-label text-muted" for="diploma">
                                                                       --Ingresar Diploma Grado de Estudio--
                                                                    </label>
                                                                <?php else: ?>
                                                                    <label class="control-label text-muted" for="diploma">
                                                                       -Actualizar Diploma Grado de Estudio-
                                                                    </label>
                                                                <?php endif; ?>
                                                                <input style="width: 92%" accept="application/pdf" name="diploma" type="file">
                                                                    <label for="diploma">
                                                                    </label>
                                                                </input>
                                                            </div>
                                                        </div>
                                                        <br>
                                                        <div class="form-group col-md-4">
                                                            <div class="text-dark">
                                                                <?php if($empleados->nombramiento==null): ?>
                                                                    <label class="control-label text-muted" for="nombramiento">
                                                                       --------Ingresar Nombramiento--------  
                                                                    </label>
                                                                <?php else: ?>
                                                                    <label class="control-label text-muted" for="nombramiento">
                                                                       -------Actualizar Nombramiento-------
                                                                    </label>
                                                                <?php endif; ?>
                                                                <input style="width: 92%" accept="application/pdf" name="nombramiento" type="file">
                                                                    <label for="nombramiento">
                                                                    </label>
                                                                </input>
                                                            </div>
                                                        </div>
                                                        <br>
                                                        <div class="form-group col-md-4">
                                                            <div class="text-dark">
                                                                <?php if($empleados->dictamen==null): ?>
                                                                    <label class="control-label text-muted" for="dictamen">
                                                                       ----------Ingresar Dictamen----------  
                                                                    </label>
                                                                <?php else: ?>
                                                                    <label class="control-label text-muted" for="dictamen">
                                                                       ---------Actualizar Dictamen---------
                                                                    </label>
                                                                <?php endif; ?>
                                                                <input style="width: 92%" accept="application/pdf" name="dictamen" type="file">
                                                                    <label for="dictamen">
                                                                    </label>
                                                                </input>
                                                            </div>
                                                        </div>
                                                        <br>
                                                        <div class="form-group col-md-4">
                                                            <div class="text-dark">
                                                                <h5>
                                                                    Agrega Documento Adicional
                                                                </h5>
                                                                <input style="width: 92%" accept="application/pdf" name="adicional" type="file">
                                                                    <label for="adicional">
                                                                    </label>
                                                                </input>
                                                            </div>
                                                        </div>
                                                    </div>
                                                        <button class="btn btn-primary" type="submit">
                                                            Guardar
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>

                        
                </div>
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\CEVI2.0\resources\views/Empleados/editEmpleados.blade.php ENDPATH**/ ?>