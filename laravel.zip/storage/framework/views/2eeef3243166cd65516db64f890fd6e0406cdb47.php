<?php $__env->startSection('content'); ?>
<div>
    <h1 class="text-center" style="color:#FDFCFC">
        Usuarios
    </h1>
</div>
<div class="row justify-content-center">
    <div class="form-group col-md-9">
        <form action="<?php echo e(url('/alta')); ?>" method="get">
            <button class="btn btn-primary btn-sm float-left" type="submit">
                + Agregar
            </button>
        </form>
        <br>
            <br>
                <div class="table-responsive">
                    <table class="table table-dark ">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">
                                    #
                                </th>
                                <th scope="col">
                                    Nombre
                                </th>
                                <th scope="col">
                                    Username
                                </th>
                                <th scope="col">
                                    Password
                                </th>
                                <th scope="col">
                                    Role
                                </th>
                                <th scope="col">
                                    Editar
                                </th>
                                <th scope="col">
                                    Eliminar
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $User): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th>
                                    <?php echo e($loop->iteration); ?>

                                </th>
                                <td>
                                    <?php echo e($User->name); ?>

                                </td>
                                <td>
                                    <?php echo e($User->email); ?>

                                </td>
                                <td>
                                    <?php echo e($User->password); ?>

                                </td>
                                <td>
                                    <?php if(($User->role_id) > 1): ?>
                                        Administrador
                                    <?php else: ?>
                                        Usuario
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <form action="<?php echo e(url($User->id.'/EditUser')); ?>" method="get">
                                        <button class="btn btn-warning " type="submit">
                                            Editar
                                        </button>
                                    </form>
                                </td>
                                <td>
                                    <form action="<?php echo e(url('/DeleteUsuarios/'.$User->id)); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <button class="btn btn-danger" onclick="return confirm('¿Borrar?');" type="submit">
                                            Eliminar
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </br>
        </br>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CEVI2.0\resources\views/IndexUser.blade.php ENDPATH**/ ?>