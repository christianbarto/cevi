<?php $__env->startSection('content'); ?>
<div class="row justify-content-center overflow-auto">
        <div class="form-group col-md-9">
        <div class="card">
            <div class="card-header">
                <h1 style="color: black">
                    Nuevo Empleado
                </h1>
                <?php if ($errors->has('Tcontrato')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Tcontrato'); ?>
                    <div class="alert alert-danger"><?php echo e('Seleccione una Relacion Laboral'); ?></div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <div class="card-body" style="background-color: #DCDCDC">
                <div class="row justify-content-center">
                    <?php if(session('verifi')): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e(session('verifi')); ?>

                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('empleados.store')); ?>" enctype="multipart/form-data" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-group col-md-3" style="">
                                <label class="control-label text-muted" for="nombre">
                                    Nombre
                                </label>
                                <input class="form-control" id="nombre" name="nombre" required type="text" value="<?php echo e(old('nombre')); ?>" >
                                </input>
                            </div>
                            <div class="form-group col-md-3" style="">
                                <label class="control-label text-muted" for="ap_paterno">
                                    Apellido Paterno
                                </label>
                                <input  class="form-control" id="ap_paterno" name="ap_paterno" value="<?php echo e(old('ap_paterno')); ?>"  required type="text">
                                </input>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="ap_materno">
                                    Apellido Materno
                                </label>
                                <input class="form-control" id="ap_materno" name="ap_materno" value="<?php echo e(old('ap_materno')); ?>"  required type="text">
                                </input>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="fecha_alta">
                                    Fecha de Alta
                                </label>
                                <input class="form-control" id="fecha_alta" name="fecha_alta" type="date" value="<?php echo e(date('Y-m-d')); ?>" min="1980-01-01" max=<?php echo e(now()); ?>>
                                </input>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="Tcontrato">
                                    Relacion Laboral
                                </label>
                                <select onChange="prueba()" class="form-control" id="Tcontrato" name="Tcontrato">
                                    <option value="" >
                                        Seleccione una opción
                                    </option>
                                    <option value="base" >
                                        PERSONAL DE BASE
                                    </option>
                                    <option value="contrato">
                                        PERSONAL DE CONTRATO
                                    </option>
                                    <option value="nombremientoConfianza">
                                        NOMBRAMIENTO CONFIANZA
                                    </option>
                                    <option value="mandosMedios">
                                        MANDOS MEDIOS
                                    </option>
                                    <option value="contratoConfianza">
                                        CONTRATO CONFIANZA
                                    </option>
                                </select>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="fecha_nombramiento" >
                                    Fecha de Nombramiento
                                </label>
                                <input class="form-control" id="fecha_nombramiento" name="fecha_nombramiento" value="<?php echo e(old('fecha_nombramiento')); ?>" 
                                type="date" disabled min="1980-01-01" max=<?php echo e(now()); ?>>
                                </input>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="correo">
                                    Correo Electronico
                                </label>
                                <input class="form-control" id="correo" name="correo" value="<?php echo e(old('correo')); ?>" type="email" required >
                                </input>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="telefono">
                                    Numero Telefonico
                                </label>
                                <input class="form-control" id="telefono" name="telefono" value="<?php echo e(old('telefono')); ?>" min="0" max="9999999999" required  type="number">
                                </input>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="genero">
                                    Genero
                                </label>
                                <select class="form-control" id="genero" name="genero">
                                    <option value="Hombre">
                                        HOMBRE
                                    </option>
                                    <option value="Mujer">
                                        MUJER
                                    </option>
                                </select>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="RFC">
                                    RFC
                                </label>
                                <input class="form-control" id="RFC" name="RFC" value="<?php echo e(old('RFC')); ?>" required style="text-transform:uppercase;" type="text" maxlength="13">
                                </input>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="puesto">
                                    Categoria
                                </label>
                                <select class="form-control" id="puesto" name="puesto" required>
                                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($categoria->descripcion); ?>">
                                        <?php echo e($categoria->identificador); ?>---<?php echo e($categoria->descripcion); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="departamento">
                                    Departamento
                                </label>
                                <select class="form-control" id="departamento" name="departamento" required>
                                <?php $__currentLoopData = $departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($departamento->descripcion); ?>">
                                        <?php echo e($departamento->id); ?> <?php echo e($departamento->descripcion); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group col-md-4">
                                <div class="text-dark">
                                    <label class="control-label text-muted" for="contrato">
                                        Contrato
                                    </label>
                                    <input accept="application/pdf" name="contrato" value="<?php echo e(old('contrato')); ?>" type="file">
                                        <label for="contrato">
                                        </label>
                                    </input>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="text-dark">
                                    <label class="control-label text-muted"  for="creden_elect">
                                        Credencial de Elector
                                    </label>
                                    <input accept="application/pdf" required  name="creden_elect" value="<?php echo e(old('creden_elect')); ?>" type="file">
                                        <label for="creden_elect">
                                        </label>
                                    </input>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="text-dark">
                                    <label class="control-label text-muted" for="acta_nac">
                                        Acta de nacimiento
                                    </label>
                                    <input accept="application/pdf" required name="acta_nac" value="<?php echo e(old('acta_nac')); ?>" type="file">
                                        <label for="acta_nac">
                                        </label>
                                    </input>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="text-dark">
                                    <label class="control-label text-muted" for="curriculum">
                                        Curriculum
                                    </label>
                                    <input accept="application/pdf" required name="curriculum" value="<?php echo e(old('curriculum')); ?>" type="file">
                                        <label for="curriculum">
                                        </label>
                                    </input>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="text-dark">
                                    <label class="control-label text-muted" for="solicitud">
                                        Solicitud de Empleo
                                    </label>
                                    <input accept="application/pdf" required name="solicitud" value="<?php echo e(old('solicitud')); ?>" type="file">
                                        <label for="solicitud">
                                        </label>
                                    </input>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="text-dark">
                                    <label class="control-label text-muted" for="cert_medico">
                                        Certificado Medico
                                    </label>
                                    <input accept="application/pdf" required name="cert_medico" value="<?php echo e(old('cert_medico')); ?>" type="file">
                                        <label for="cert_medico">
                                        </label>
                                    </input>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="text-dark">
                                    <label class="control-label text-muted" for="cart_recomend">
                                        Carta de Recomendacion
                                    </label>
                                    <input accept="application/pdf" required name="cart_recomend" value="<?php echo e(old('cart_recomend')); ?>" type="file">
                                        <label for="cart_recomend">
                                        </label>
                                    </input>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="text-dark">
                                    <label class="control-label text-muted" for="fotografia">
                                        Fotografia
                                    </label>
                                    <input accept="application/pdf" required name="fotografia" value="<?php echo e(old('fotografia')); ?>" type="file">
                                        <label for="fotografia">
                                        </label>
                                    </input>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="text-dark">
                                    <label class="control-label text-muted" for="const_Noinhab">
                                        Constancia de No Inhabilitacion
                                    </label>
                                    <input accept="application/pdf" required name="const_Noinhab" value="<?php echo e(old('const_Noinhab')); ?>" type="file">
                                        <label for="const_Noinhab">
                                        </label>
                                    </input>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="text-dark">
                                    <label class="control-label text-muted" for="comp_Dom">
                                        Comprobante de Domicilio
                                    </label>
                                    <input accept="application/pdf" required name="comp_Dom" value="<?php echo e(old('comp_Dom')); ?>" type="file">
                                        <label for="comp_Dom">
                                        </label>
                                    </input>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="text-dark">
                                    <label class="control-label text-muted" for="licencia">
                                        Licencia de Conducir
                                    </label>
                                    <input accept="application/pdf" name="licencia" value="<?php echo e(old('licencia')); ?>" type="file">
                                        <label for="licencia">
                                        </label>
                                    </input>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="text-dark">
                                    <label class="control-label text-muted" for="nss">
                                        Numero de Seguro Social
                                    </label>
                                    <input accept="application/pdf" required name="nss" value="<?php echo e(old('nss')); ?>" type="file">
                                        <label for="nss">
                                        </label>
                                    </input>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="text-dark">
                                    <label class="control-label text-muted" for="infonavit">
                                        Infonavit
                                    </label>
                                    <input accept="application/pdf" name="infonavit" value="<?php echo e(old('infonavit')); ?>" type="file">
                                        <label for="infonavit">
                                        </label>
                                    </input>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="text-dark">
                                    <label class="control-label text-muted" for="rfc_doc">
                                        Constancia de RFC
                                    </label>
                                    <input accept="application/pdf" required name="rfc_doc" value="<?php echo e(old('rfc_doc')); ?>" type="file">
                                        <label for="rfc_doc">
                                        </label>
                                    </input>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="text-dark">
                                    <label class="control-label text-muted" for="cartilla">
                                        Cartilla Militar Liberada
                                    </label>
                                    <input accept="application/pdf" name="cartilla" value="<?php echo e(old('cartilla')); ?>" type="file">
                                        <label for="cartilla">
                                        </label>
                                    </input>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="text-dark">
                                    <label class="control-label text-muted"  for="curp">
                                        Clave Única de Registro de Poblacional (CURP)
                                    </label>
                                    <input accept="application/pdf" required name="curp" value="<?php echo e(old('curp')); ?>" type="file">
                                        <label for="curp">
                                        </label>
                                    </input>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="text-dark">
                                    <label class="control-label text-muted" for="diploma">
                                        Diploma de Grado de Estudio
                                    </label>
                                    <input accept="application/pdf" required name="diploma" value="<?php echo e(old('diploma')); ?>" type="file">
                                        <label for="diploma">
                                        </label>
                                    </input>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="text-dark">
                                    <label class="control-label text-muted" for="nombramiento">
                                        Nombramiento
                                    </label>
                                    <input accept="application/pdf" name="nombramiento" value="<?php echo e(old('nombramiento')); ?>" type="file">
                                        <label for="nombramiento">
                                        </label>
                                    </input>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="text-dark">
                                    <label class="control-label text-muted" for="dictamen">
                                        Dictamen
                                    </label>
                                    <input accept="application/pdf" required name="dictamen" value="<?php echo e(old('dictamen')); ?>" type="file">
                                        <label for="dictamen">
                                        </label>
                                    </input>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="text-dark">
                                    <label class="control-label text-muted" for="adicionales">
                                        Documentos Adicionales
                                    </label>
                                    <input accept="application/pdf" name="adicionales" value="<?php echo e(old('adicionales')); ?>" type="file">
                                        <label for="adicionales">
                                        </label>
                                    </input>
                                </div>
                            </div>
                        </div>
                        <div class="form-group text-center">
                            <!-- Submit Button -->
                            <button class="btn btn-primary " type="submit">
                                Guardar
                            </button>
                        </div> 
                    </form>
                </div>    
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\CEVI2.0\resources\views/Empleados/createEmpleados.blade.php ENDPATH**/ ?>