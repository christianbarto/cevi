<?php $__env->startSection('content'); ?>
<div class="row justify-content-center overflow-auto">
    <div class="form-group col-md-9">
        <div class="card">
            <div class="card-header" style="color:black">
                <h1>
                   Empleados
                </h1>
            </div>
            <div class="card-body" style="background-color: #DCDCDC">
                    <div class="row float-left col-md-10">
                        <div class="form-group">
                            <div class="card">
                        <form class="form-inline" action="<?php echo e(url('/buscarEmpleado')); ?>" method="get">
                            <select class="form-control" id="seleccion" name="seleccion">
                                <option value="id">
                                    N° de Trabajador
                                </option>
                                <option value="nombre">
                                    Nombre
                                </option>
                                <option value="RFC">
                                    RFC
                                </option>
                                <option value="paterno">
                                    Apellido Paterno
                                </option>
                                <option value="materno">
                                    Apellido Materno
                                </option>
                            </select>
                            <input class="form-control" id="search" name="search" type="text" ></input>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-search"></i>
                            </button>
                            <button method="get" action="<?php echo e(url('/IndexEmpleado')); ?>" class="btn btn-success">
                                <i class="fas fa-sync-alt"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <form action="<?php echo e(url('/createEmpleado')); ?>" method="get">
                <button class="btn btn-primary btn-sm float-left" type="submit">
                    + Agregar
                </button>
            </form>
        <br>
        <br>
        <br>
        <?php if(session('verifi')): ?>
            <div class="alert alert-danger" role="alert">
                    <?php echo e(session('verifi')); ?>

            </div>
        <?php endif; ?>
        <h2 class="text-center" style="color:black">
        Activos
        </h2>
                    <div class="table-responsive" style="width:100%;overflow:auto; max-height:430px;">
                        <table class="table table-dark ">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col">
                                        N° de trabajador
                                    </th>
                                    <th scope="col">
                                        RFC
                                    </th>
                                    <th scope="col">
                                        Nombre(s)
                                    </th>
                                    <th scope="col">
                                        Apellido Paterno
                                    </th>
                                    <th scope="col">
                                        Apellido Materno
                                    </th>
                                    <th scope="col">
                                        Ver
                                    </th>
                                    <th scope="col">
                                        Editar
                                    </th>
                                    <?php if(Auth::user()->role_id==2): ?>
                                    <th scope="col">
                                        Inactivar
                                    </th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($Empleado->estatus == 'activo'): ?>
                                <tr>
                                    <td>
                                        <?php echo e($Empleado->id); ?>

                                    </td>
                                    <td>
                                        <?php echo e($Empleado->RFC); ?>

                                    </td>
                                    <td>
                                        <?php echo e($Empleado->nombre); ?>

                                    </td>
                                    <td>
                                        <?php echo e($Empleado->ap_paterno); ?>

                                    </td>
                                    <td>
                                        <?php echo e($Empleado->ap_materno); ?>

                                    </td>

                                    
                                    <td>
                                        <form action="<?php echo e(route('empleados.busqueda')); ?>"   method="get">
                                            <button class="btn btn-success float-left" name="id"  type="submit" value=<?php echo e($Empleado->id); ?>>
                                                <i class="fas fa-user-check"></i>
                                            </button>
                                        </form>
                                    </td>

                                    

                                    <td>
                                        <form action="<?php echo e(route('empleados.edit')); ?>"   method="get">
                                            <button class="btn btn-warning" name="id"  type="submit" value=<?php echo e($Empleado->id); ?>>
                                                <i class="fas fa-user-edit"></i>
                                            </button>
                                        </form>
                                        
                                    </td>

                                    
                                    <?php if(Auth::user()->role_id==2): ?>
                                    <td>
                                        <a class="btn btn-danger pull-right" data-target="#DeleteUsuario<?php echo e($Empleado->id); ?>" data-toggle="modal" href="#" type="submit">
                                           <i class="fas fa-user-times"></i>
                                            </i>
                                        </a>
                                        <div aria-hidden="true" aria-labelledby="exampleModalLabl" class="modal fade" id="DeleteUsuario<?php echo e($Empleado->id); ?>" tabindex="-1">
                                            <div class="modal-dialog modal-sm">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h3 class="text-center" style="color:black">
                                                            Selecciona la fecha y causa de la baja
                                                        </h3>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form action="<?php echo e(route ('empleado.disable',$Empleado->id)); ?>" method="post">
                                                        <?php echo e(csrf_field()); ?> <?php echo e(method_field('put')); ?>

                                                            <div class="form-group col-md-12">
                                                                <label style="color:black">
                                                                    Fecha de baja
                                                                </label>
                                                                <input class="form-control" id="fecha_baja" name="fecha_baja" type="date" value="<?php echo e(date('Y-m-d')); ?>">
                                                                </input>
                                                            </div>
                                                            <div class="form-group col-md-12">
                                                                <label style="color:black">
                                                                    Causa de baja
                                                                </label>
                                                                <textarea name="causa_baja" rows="3" cols="30" value="<?php echo e(old('causa_baja')); ?>" required></textarea>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button class="btn btn-primary" type="submit">
                                                                    Guardar
                                                                </button>
                                                                <button class="btn btn-secondary" data-dismiss="modal" type="button">Cancelar</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </br>
            </br>
                                    
        <h2 class="text-center" style="color: black">
            Inactivos
        </h2>
                    <div class="table-responsive" style="width:100%;overflow:auto; max-height:430px;">
                        <table class="table table-dark ">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col">
                                        N° de Trabajador
                                    </th>
                                    <th scope="col">
                                        RFC
                                    </th>
                                    <th scope="col">
                                        Nombre(s)
                                    </th>
                                    <th scope="col">
                                        Apellido Paterno
                                    </th>
                                    <th scope="col">
                                        Apellido Materno
                                    </th>
                                    <th scope="col">
                                        Fecha Baja
                                    </th>
                                    <th scope="col">
                                        Causa Baja
                                    </th>
                                    <th scope="col">
                                        Ver
                                    </th>
                                    <th scope="col">
                                        Editar
                                    </th>
                                    <?php if(Auth::user()->role_id==2): ?>
                                    <th scope="col">
                                        Activar
                                    </th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($Empleado->estatus == 'inactivo'): ?>
                                <tr>
                                    <td>
                                        <?php echo e($Empleado->id); ?>

                                    </td>
                                    <td>
                                        <?php echo e($Empleado->RFC); ?>

                                    </td>
                                    <td>
                                        <?php echo e($Empleado->nombre); ?>

                                    </td>
                                    <td>
                                        <?php echo e($Empleado->ap_paterno); ?>

                                    </td>
                                    <td>
                                        <?php echo e($Empleado->ap_materno); ?>

                                    </td>
                                    <td>
                                        <?php if($Empleado->fecha_baja==null): ?>
                                            Sin fecha de baja
                                        <?php else: ?>
                                        <?php echo e(Date::parse($Empleado->fecha_baja)->format('j \d\e F \d\e Y')); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($Empleado->causa_baja==null): ?>
                                            Sin causa de baja
                                        <?php else: ?>
                                        <?php echo e($Empleado->causa_baja); ?>

                                        <?php endif; ?>
                                    </td>
                                    
                                    <td>
                                        <form action="<?php echo e(route('empleados.busqueda')); ?>"   method="get">
                                            <button class="btn btn-success float-left" name="id"  type="submit" value=<?php echo e($Empleado->id); ?>>
                                                <i class="fas fa-user-check"></i>
                                            </button>
                                        </form>
                                    </td>

                                    

                                    <td>
                                        <form action="<?php echo e(route('empleados.edit')); ?>"   method="get">
                                            <button class="btn btn-warning" name="id"  type="submit" value=<?php echo e($Empleado->id); ?>>
                                                <i class="fas fa-user-edit"></i>
                                            </button>
                                        </form>
                                        
                                    </td>
                                    

                                    
                                    <?php if(Auth::user()->role_id==2): ?>
                                    <td>
                                        <form action="<?php echo e(route ('empleado.enable',$Empleado->id)); ?>"  method="post">
                                            <?php echo e(csrf_field()); ?> <?php echo e(method_field('put')); ?>

                                        <button class="btn btn btn-info pull-right" type="submit">
                                            <i class="fas fa-user-shield"></i>
                                        </button>
                                        </form>
                                    </td>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\CEVI2.0\resources\views/Empleados/IndexEmpleado.blade.php ENDPATH**/ ?>