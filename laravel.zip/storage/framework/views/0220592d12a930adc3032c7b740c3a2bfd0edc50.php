<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="form-group col-md-9">
        <div class="card">
            <div class="card-header" style="color:black">
                <h1>
                   Registrar Departamento
                </h1>
            </div>
            <div class="card-body" style="background-color: #DCDCDC">
                <div class="row justify-content-center">
                    <form action="<?php echo e(route('departamentos.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php if(session('verifi')): ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo e(session('verifi')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="form-row">
                            <div class="form-group col-md-3">
                                <label class="control-label" for="name" style="color:black">
                                    Id
                                </label>
                                <input class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>" type="text" required>
                                </input>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label" for="username" style="color:black">
                                    Descripción
                                </label>
                                <input class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>" type="text" required>
                                </input>
                            </div>
                        </div>
                        <div class="form-group text-center">
                            <button class="btn btn-primary " type="submit">
                                Guardar
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CEVI2.0\resources\views/Departamentos/createDepartamentos.blade.php ENDPATH**/ ?>