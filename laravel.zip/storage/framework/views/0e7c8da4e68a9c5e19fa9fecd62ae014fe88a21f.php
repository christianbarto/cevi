<h1 class="text-center">
    Empleados Activos
</h1>
<div class="table-responsive">
    <table class="table table-dark ">
        <thead class="thead-light">
            <tr>
                <th scope="col">
                    #
                </th>
                <th scope="col">
                    Nombre(s)
                </th>
                <th scope="col">
                    Apellido Paterno
                </th>
                <th scope="col">
                    Apellido Materno
                </th>
                <th scope="col">
                    Estatus
                </th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($Empleado->estatus == 'activo'): ?>
            <tr>
                <th>
                    <?php echo e($loop->iteration); ?>

                </th>
                <td>
                    <?php echo e($Empleado->nombre); ?>

                </td>
                <td>
                    <?php echo e($Empleado->ap_paterno); ?>

                </td>
                <td>
                    <?php echo e($Empleado->ap_materno); ?>

                </td>
                <td>
                    <?php echo e($Empleado->estatus); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\CEVI2.0\resources\views/pdf/IndexEmpleado.blade.php ENDPATH**/ ?>