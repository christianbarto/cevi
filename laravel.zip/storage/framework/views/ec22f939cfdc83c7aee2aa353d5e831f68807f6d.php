<?php $__env->startSection('content'); ?>
<div class="container-fluid" style="background-color:#7D3C98">
    <h1>
        <?php echo e($empleados->nombre); ?> <?php echo e($empleados->ap_materno); ?> <?php echo e($empleados->ap_paterno); ?>

    </h1>
    <div class="card">
        <div class="card-body">
            <div class="row justify-content-center">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CEVI2.0\resources\views/Empleados/showEmpleados.blade.php ENDPATH**/ ?>