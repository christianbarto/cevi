<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="form-group col-md-9">
        <div class="card">
            <div class="card-header" style="color:black">
                <h1>
                   Usuarios
                </h1>
            </div>
            <div class="card-body" style="background-color: #DCDCDC">
                <form action="<?php echo e(url('/alta')); ?>" method="get">
                    <button class="btn btn-primary btn-sm float-left" type="submit">
                        + Agregar
                    </button>
                </form>
                <br>
                    <br>
                        <div class="table-responsive">
                            <table class="table table-dark ">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col">
                                            Nombre
                                        </th>
                                        <th scope="col">
                                            Apellido Paterno
                                        </th>
                                        <th scope="col">
                                            Apellido Materno
                                        </th>
                                        <th scope="col">
                                            Correo
                                        </th>
                                        <th scope="col">
                                            Role
                                        </th>
                                        <th scope="col">
                                            Editar
                                        </th>
                                        <th scope="col">
                                            Eliminar
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $User): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php echo e($User->name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($User->ap_paterno); ?>

                                        </td>
                                        <td>
                                            <?php echo e($User->ap_materno); ?>

                                        </td>
                                        <td>
                                            <?php echo e($User->email); ?>

                                        </td>
                                        <td>
                                            <?php if($User->role_id > 1): ?>
                                                Administrador
                                            <?php else: ?>
                                                Usuario
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a class="btn btn-warning pull-right" data-target="#EditUsuario<?php echo e($User->id); ?>" data-toggle="modal" href="#" type="submit">
                                                <i class="fas fa-user-edit"></i>
                                            </a>
                                            <div aria-hidden="true" aria-labelledby="exampleModalLabel" class="modal fade" id="EditUsuario<?php echo e($User->id); ?>" tabindex="-1">
                                                <div class="modal-dialog modal-sm">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title text-dark">
                                                                Editar Usuario
                                                            </h5>
                                                            <button class="close" data-dismiss="modal" type="button">
                                                                <span>
                                                                &times;
                                                                </span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form action="<?php echo e(route ('user.update',$User)); ?>" method="post">
                                                            <?php echo e(csrf_field()); ?> <?php echo e(method_field('put')); ?>

                                                            <div class="form-group">
                                                                <label for="" class="text-dark float-left">Nombre</label>
                                                                <input type="text" name ="name" class="form-control" value=<?php echo e($User->name); ?>>
                                                                </input>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="ap_paterno" class="text-dark float-left">Apellido Paterno</label>
                                                                <input type="text" name ="ap_paterno" class="form-control" value=<?php echo e($User->ap_paterno); ?>>
                                                                </input>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="ap_materno" class="text-dark float-left">Apellido Materno</label>
                                                                <input type="text" name ="ap_materno" class="form-control" value=<?php echo e($User->ap_materno); ?>>
                                                                </input>
                                                            </div>
                                                            <?php if($User->email=='admin_agustin@mail.com' || $User->email=='user@mail.com'): ?>
                                                                <div class="form-group">
                                                                    <label for="" class="text-dark float-left">Correo</label>
                                                                    <input type="text" readonly name="email" class="form-control" value=<?php echo e($User->email); ?>>
                                                                    </input>
                                                                </div>
                                                            <?php else: ?>
                                                                <div class="form-group">
                                                                    <label for="" class="text-dark float-left">Correo</label>
                                                                    <input type="text"  name="email" class="form-control" value=<?php echo e($User->email); ?>>
                                                                    </input>
                                                                </div>
                                                            <?php endif; ?>
                                                            <div class="form-group">
                                                                <label for="" class="text-dark float-left">Contraseña</label>
                                                                <input type="text" name ="password" class="form-control" placeholder="Ingresa Nueva Contraseña">
                                                                </input>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="control-label text-dark float-left" for="role_id">
                                                                    Role
                                                                </label>
                                                                <select class="form-control" id="role_id" name="role_id">
                                                                <option value="2">
                                                                    Administrador
                                                                </option>
                                                                <option value="1">
                                                                    Usuario
                                                                </option>
                                                                </select>
                                                            </div>
                                                            </div>
                                                                <div class="modal-footer">
                                                                    <button class="btn btn-primary" type="submit">
                                                                        Guardar
                                                                    </button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                                <td>
                                                <?php if($User->email=='admin_agustin@mail.com' || $User->email=='user@mail.com'): ?>
                                                    <form action="<?php echo e(url('/DeleteUsuarios/'.$User->id)); ?>" method="POST">
                                                        <?php echo e(csrf_field()); ?>

                                                        <button class="btn btn-danger" onclick="return confirm('¿Borrar?');" type="submit" disabled>
                                                            <i class="fas fa-user-times"></i>
                                                        </button>
                                                    </form>
                                                <?php else: ?>
                                                    <form action="<?php echo e(url('/DeleteUsuarios/'.$User->id)); ?>" method="POST">
                                                        <?php echo e(csrf_field()); ?>

                                                        <button class="btn btn-danger" onclick="return confirm('¿Borrar?');" type="submit">
                                                            <i class="fas fa-user-times"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                                </td>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </br>
                </br>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CEVI2.0\resources\views/user/IndexUser.blade.php ENDPATH**/ ?>