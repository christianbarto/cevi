<img height="90" src="img/CEVILOGO2020.jpg" width="428" style="margin-top:0px;"></img>
<h4 style="text-align: left;">
    Generado: <?php echo e(Date::parse(now())->format('j \d\e F \d\e Y')); ?><br>
    Usuario: <?php echo e(Auth::user()->name); ?>

</h4>
<h3 >
    Empleado:<br>
    <?php echo e($nombre); ?><br>
    Asistencia del periodo:<br>
    Del <?php echo e(Date::parse($inicio)->format('j \d\e F \d\e Y')); ?> al <?php echo e(Date::parse($fin)->format('j \d\e F \d\e Y')); ?><br>
</h3>    
            <table border="1" align="center" cellspacing="0" cellpadding="1" style="text-align: center;">
                <thead >
                    <tr>
                            <th scope="col">
                                Fecha
                            </th>
                            <th scope="col">
                                RFC
                            </th>
                            <th scope="col">
                                Nombre
                            </th>
                            <th scope="col">
                                Apellido Paterno
                            </th>
                            <th scope="col">
                                Apellido Materno
                            </th>
                            <th scope="col">
                                Hora de Entrada
                            </th>
                            <th scope="col">
                                Hora de salida
                            </th>
                            <th scope="col">
                                Incidencia
                            </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $Relojes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Reloj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                            <td>
                                <?php echo e(Date::parse($Reloj->fecha)->format('j \d\e F \d\e Y')); ?>

                            </td>
                            <td>
                                <?php echo e($Reloj->RFC); ?>

                            </td>
                            <td>
                                <?php echo e($Reloj->nombre); ?>

                            </td>
                            <td>
                                <?php echo e($Reloj->ap_paterno); ?>

                            </td>
                            <td>
                                <?php echo e($Reloj->ap_materno); ?>

                            </td>
                            <td>
                                <?php if(($Reloj->entrada)===('00:00:00')): ?>
                                    N/A
                                <?php else: ?>
                                <?php echo e(Date::parse($Reloj->entrada)->isoFormat('h:mm A')); ?>      
                                <?php endif; ?>                            
                            </td>
                            <td>
                                <?php if(($Reloj->salida)===('00:00:00')): ?>
                                    N/A
                                <?php else: ?>
                                <?php echo e(Date::parse($Reloj->salida)->isoFormat('h:mm A')); ?>   
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($Reloj->incidencia); ?>

                            </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                </tbody>
            </table><?php /**PATH C:\xampp\htdocs\CEVI2.0\resources\views/pdf/asistenciasEP.blade.php ENDPATH**/ ?>