<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="form-group col-md-9">
        <div class="card">
            <div class="card-header" style="color:black">
                <h1 class="text-center" >
                    Importar Reloj Checador
                </h1>
            </div>
            <div class="card-body" style="background-color: #DCDCDC">
                <div class="row justify-content-center">
                    <form action="<?php echo e(route('checador.importxml')); ?>" enctype="multipart/form-data" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php if(Session::has('message')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(Session::get('message')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                            <ul class="text-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="alert alert-danger" role="alert">
                                     <?php echo e($error); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                        <div class="form-group">
                            <input class="form-control form-control-lg" style="background-color: #DCDCDC" accept=".xml" name="xml" type="file"/>
                        </div>
                        <button class="btn btn-primary">
                            Agregar
                        </button>
                    </form>
                </div>
            </div>
            <div class="table-responsive" style="width:100%;overflow:auto; max-height:430px;">
                <table class="table table-dark">
                    <thead class="thead-light">
                        <tr>
                            <th scope="col">
                                RFC
                            </th>
                            <th scope="col">
                                Nombre(s)
                            </th>
                            <th scope="col">
                                Apellido Paterno
                            </th>
                            <th scope="col">
                                Apellido Materno
                            </th>
                            <th scope="col">
                                Fecha
                            </th>
                            <th scope="col">
                                Hora de Entrada
                            </th>
                            <th scope="col">
                                Hora de Salida
                            </th>
                            <th scope="col">
                                Incidencia
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $Relojes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Reloj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($Reloj->RFC); ?>

                            </td>
                            <td>
                                <?php echo e($Reloj->nombre); ?>

                            </td>
                            <td>
                                <?php echo e($Reloj->ap_paterno); ?>

                            </td>
                            <td>
                                <?php echo e($Reloj->ap_materno); ?>

                            </td>
                            <td>
                                <?php echo e(Date::parse($Reloj->fecha)->format('j \d\e F \d\e Y')); ?>

                            </td>
                            <td>
                                <?php if(($Reloj->entrada)===('00:00:00')): ?>
                                
                                    N/A
                                
                                <?php else: ?>
                                <?php echo e(Date::parse($Reloj->entrada)->isoFormat('h:mm A')); ?>

                                    
                                <?php endif; ?>                            
                            </td>
                            <td>
                                <?php if(($Reloj->salida)===('00:00:00')): ?>
                                
                                    N/A
                                
                                <?php else: ?>
                                <?php echo e(Date::parse($Reloj->salida)->isoFormat('h:mm A')); ?>


                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($Reloj->incidencia); ?>

                            </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\CEVI2.0\resources\views/Reloj/IndexXml.blade.php ENDPATH**/ ?>