<?php $__env->startSection('content'); ?>
<h1 class="text-center" style="color:#FDFCFC">
    Editar Usuario
</h1>
<div class="row justify-content-center">
    <div class="form-group col-md-8">
        <table class="table table table-striped ">
            <thead>
                <tr>
                    <th scope="col">
                        #
                    </th>
                    <th scope="col">
                        Nombre
                    </th>
                    <th scope="col">
                        Username
                    </th>
                    <th scope="col">
                        Password
                    </th>
                    <th scope="col">
                        Role
                    </th>
                    <th scope="col">
                        Editar
                    </th>
                    <th scope="col">
                        Eliminar
                    </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th scope="row">
                        1
                    </th>
                    <td>
                    </td>
                    <td>
                    </td>
                    <td>
                    </td>
                    <td>
                    </td>
                    <td>
                        <button class="btn btn-warning text-dark">
                            Editar
                        </button>
                    </td>
                    <td>
                        <button class="btn btn-danger text-dark">
                            Eliminar
                        </button>
                    </td>
                </tr>
            </tbody>
            <?php $__env->stopSection(); ?>
        </table>
    </div>
</div>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CEVI2.0\resources\views/EditaUser.blade.php ENDPATH**/ ?>