<?php $__env->startSection('content'); ?>  
<div class="row justify-content-center">
    <div class="form-group col-md-9">
        <div class="card">
            <div class="card-header" style="color:black">
                <h1>
                   Categorias
                </h1>
            </div>
            <?php if(session('verifi')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('verifi')); ?>

                </div>
            <?php endif; ?>
            <div class="card-body" style="background-color: #DCDCDC">
                <div class="row float-left col-md-10">
                    <div class="form-group">
                        <div class="card">
                            <form class="form-inline" action="<?php echo e(url('/buscarCategoria')); ?>" method="get">
                                <select class="form-control" id="seleccion" name="seleccion">
                                    <option value="id">
                                        Id
                                    </option>
                                    <option value="descripcion">
                                        Descripción
                                    </option>
                                </select>
                                <input class="form-control" id="search" name="search" type="text" ></input>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-search"></i>
                                </button>
                                <button method="get" href="<?php echo e(url('/IndexCategorias')); ?>" class="btn btn-success">
                                    <i class="fas fa-sync-alt"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <a class="btn btn-primary float-left" data-target="#createCategoria" data-toggle="modal" href="#" type="submit">
                    + Agregar
                </a>
                <div aria-hidden="true" aria-labelledby="exampleModalLabl" class="modal fade" id="createCategoria" tabindex="-1">
                    <div class="modal-dialog modal-sm">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3 class="text-center text-muted" style="color:gray">
                                    Crear Nueva Categoria
                                </h3>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route ('categoria.store')); ?>" method="post">
                                    <?php echo e(csrf_field()); ?> <?php echo e(method_field('post')); ?>

                                <div class="form-group col-md-12">
                                    <input class="form-control" id="identificador" name="identificador" type="text" placeholder="Id" required>
                                    </input>
                                </div>
                                <div class="form-group col-md-12">
                                    <input class="form-control" id="descripcion" name="descripcion" type="text" placeholder="Descripción" required>
                                    </input>
                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-primary" type="submit">
                                        Guardar
                                    </button>
                                </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="table-responsive" style="width:100%;overflow:auto; max-height:430px;">
                    <table class="table table-dark ">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">
                                    Id
                                </th>
                                <th scope="col">
                                    Descripción
                                </th>
                                <th scope="col">
                                    Editar
                                </th>
                                <?php if(Auth::user()->role_id==2): ?>
                                <th scope="col">
                                    Eliminar
                                </th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                             <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                   <?php echo e($categoria->identificador); ?>

                                </td>
                                <td>
                                    <?php echo e($categoria->descripcion); ?>

                                </td>
                                <td>
                                    <?php if(Auth::user()->role_id==2): ?>
                                    <a class="btn btn-warning pull-right" data-target="#EditUsuario<?php echo e($categoria->id); ?>" data-toggle="modal" href="#" type="submit">
                                           <i class="fas fa-user-edit"></i>
                                            </i>
                                        </a>
                                        <div aria-hidden="true" aria-labelledby="exampleModalLabl" class="modal fade" id="EditUsuario<?php echo e($categoria->id); ?>" tabindex="-1">
                                            <div class="modal-dialog ">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title text-dark">
                                                            <?php echo e($categoria->descripcion); ?> 
                                                        </h5>
                                                        <button class="close" data-dismiss="modal" type="button">
                                                            <span>
                                                                ×
                                                            </span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body carta">
                                                        <form action="<?php echo e(route ('categoria.update',$categoria->id)); ?>"  method="post">
                                                        <?php echo e(csrf_field()); ?> <?php echo e(method_field('put')); ?>

                                                            <div class="form-group">
                                                                <label class="control-label text-muted" for="id">
                                                                    Id
                                                                </label>
                                                                <label class="form-control" style="background-color: #85929E" id="identificador" name="identificador">
                                                                    <?php echo e($categoria->identificador); ?>

                                                                </label>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="control-label text-muted" for="nombre">
                                                                    Descripción
                                                                </label>
                                                                <input class="form-control" id="descripcion" name="descripcion" type="text" value="<?php echo e($categoria->descripcion); ?>">   
                                                                </input>
                                                            </div>
                                                            
                                                    <div class="modal-footer">
                                                        <button class="btn btn-primary" type="submit">
                                                            Guardar
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    </td>
                                </td>
                                <td>
                                    <?php if(Auth::user()->role_id==2): ?>
                                        <form action="<?php echo e(route ('categoria.delete',$categoria->id)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <button class="btn btn-danger" onclick="return confirm('¿Borrar?');" type="submit">
                                                <i class="fas fa-user-times"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CEVI2.0\resources\views/Categorias/IndexCategorias.blade.php ENDPATH**/ ?>