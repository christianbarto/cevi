<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
            <meta content="width=device-width,user-scalable=no, initial-scale=1, maximum-scale=1.0" name="viewport">
                <!-- CSRF Token -->
                <meta content="<?php echo e(csrf_token()); ?>" name="csrf-token">
                    <title>
                        <?php echo e('CEVI'); ?>

                    </title>
                    <!-- Scripts -->
                    <script defer="" src="<?php echo e(asset('js/app.js')); ?>">
                    </script>
                    <script crossorigin="anonymous" src="https://kit.fontawesome.com/afca8b434b.js">
                    </script>
                    <!-- Fonts -->
                    <link href="//fonts.gstatic.com" rel="dns-prefetch"/>
                    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet"/>
                    <!-- Styles -->
                    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet"/>
                    <link href="<?php echo e(asset('css/estilos.css')); ?>" rel="stylesheet"/>
    </head>
    <style>
        body{
                background-image: url(img/fondo.png);
                background-color: rgba(0,0,0,0.6);
                background-size: 4000px;
                text-align: center;
                background-position: center center;
                background-size: cover;
                background-repeat: repeat-x;
                position: relative;
            }
    </style>
    <body>
        <br>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header" style="color: black">
                                Reestablecer Contraseña
                        </div>
                        <div class="card-body">
                            <?php if(session('status')): ?>
                                <div class="alert alert-success" role="alert">
                                    Se Envio un Correo de Reestablecimiento
                                </div>
                            <?php endif; ?>

                            <form method="POST" action="<?php echo e(route('password.email')); ?>">
                                <?php echo csrf_field(); ?>

                                <div class="form-group row">
                                    <label for="email" class="col-md-4 col-form-label text-md-right" style="color: black">
                                            Dirección de Correo
                                    </label>

                                    <div class="col-md-6">
                                        <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                                        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong>No Existe el Usuario</strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>

                                <div class="form-group row mb-0">
                                    <div class="col-md-6 offset-md-4">
                                        <button type="submit" class="btn btn-primary">  
                                                Enviar
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\wamp64\www\CEVI2.0\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>