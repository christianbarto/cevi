<img height="90" src="img/CEVILOGO2020.jpg" width="428" style="margin-top:0px;"></img>
<h4 style="text-align: left;">
    Generado: <?php echo e(Date::parse(now())->format('j \d\e F \d\e Y')); ?><br>
    Usuario: <?php echo e(Auth::user()->name); ?>

</h4>
<h3>
    Empleados de cada departamento
</h3>

    <table border="1" align="center" cellspacing="0" cellpadding="1" style="text-align: center;">
        <thead class="thead-light">
            <tr>
                <th scope="col">
                    RFC
                </th>
                <th scope="col">
                    Nombre(s)
                </th>
                <th scope="col">
                    Apellido Paterno
                </th>
                <th scope="col">
                    Apellido Materno
                </th>     
                <th scope="col">
                    Departamento
                </th>      
                <th scope="col">
                    Total de Empleados
                </th>  
            </tr>
        </thead>
        <tbody>
           <?php $__currentLoopData = $departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php
          $conteo=1;
         ?>
             <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php if($Empleado->departamento==$departamento->descripcion): ?>
             <tr>
                 <td>
                     <?php echo e($Empleado->RFC); ?>

                 </td>
                 <td>
                     <?php echo e($Empleado->nombre); ?>

                 </td>
                 <td>
                     <?php echo e($Empleado->ap_paterno); ?>

                 </td>
                 <td>
                     <?php echo e($Empleado->ap_materno); ?>

                 </td>
                 <td>
                     <?php echo e($Empleado->departamento); ?>

                 </td>
                 <td>
                     <?php echo e($conteo); ?>

                 </td>
                 <?php
                  $conteo++;
                 ?>
             </tr>
             <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php echo e($conteo); ?>

         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table><?php /**PATH C:\xampp\htdocs\CEVI2.0\resources\views/pdf/IndexEmpleadoTD.blade.php ENDPATH**/ ?>