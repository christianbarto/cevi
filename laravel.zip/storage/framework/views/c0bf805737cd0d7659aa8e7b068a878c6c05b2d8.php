<head>
<style type="text/css">
    .color{
        background-color: #D4EFDF;
    }
    tr:nth-child(even){
        background-color: #ddd;
    }
</style>
</head>
<body>
<img height="90" src="img/CEVILOGO2020.jpg" width="428" style="margin-top:0px;"></img>
<h4 style="text-align: right;">
    Generado: <?php echo e(Date::parse(now())->format('j \d\e F \d\e Y')); ?><br>
    Usuario: <?php echo e(Auth::user()->name); ?>

</h4>
<h3>
    Asistencias por Empleado
</h3>
    <table border="1" align="center" cellspacing="0" cellpadding="1" style="text-align: center;">
                    <thead>
                        <tr class="color">
                            <th scope="col">
                                RFC
                            </th>
                            <th scope="col">
                                Nombre(s)
                            </th>
                            <th scope="col">
                                Ap. Paterno
                            </th>
                            <th scope="col">
                                Ap. Materno
                            </th>
                            <th scope="col">
                                Fecha
                            </th>
                            <th scope="col">
                                Hora Entrada
                            </th>
                            <th scope="col">
                                Hora salida
                            </th>
                            <th scope="col">
                                Incidencia
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($empleado->RFC); ?>

                            </td>
                            <td>
                                <?php echo e($empleado->nombre); ?>

                            </td>
                            <td>
                                <?php echo e($empleado->ap_paterno); ?>

                            </td>
                            <td>
                                <?php echo e($empleado->ap_materno); ?>

                            </td>
                            <td>
                                <?php echo e(Date::parse($empleado->fecha)->format('j \d\e F \d\e Y')); ?>

                            </td>
                            <td>
                                <?php if(($empleado->entrada)===('00:00:00')): ?>
                                    N/A
                                <?php else: ?>
                                    <?php echo e(Date::parse($empleado->entrada)->isoFormat('h:mm A')); ?>   
                                <?php endif; ?>                            
                            </td>
                            <td>
                                <?php if(($empleado->salida)===('00:00:00')): ?>
                                    N/A
                                <?php else: ?>
                                    <?php echo e(Date::parse($empleado->salida)->isoFormat('h:mm A')); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($empleado->incidencia); ?>

                            </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </tbody>
                </table>
</body><?php /**PATH C:\wamp64\www\CEVI2.0\resources\views/pdf/asistenciasE.blade.php ENDPATH**/ ?>