<?php $__env->startSection('content'); ?>
<?php echo e(csrf_field()); ?>

<div class="card">
    <div class="card-body">
        <input name="_method" type="hidden" value="PUT">
            <div class="form-group">
                <label for="title">
                    Titulo
                </label>
                <input id="nombre" name="nombre" type="text" value="Texto inicial">
                </input>
            </div>
            <div class="form-group">
            </div>
        </input>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CEVI2.0\resources\views/RegistrarEmpleado.blade.php ENDPATH**/ ?>