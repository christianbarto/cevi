<?php $__env->startSection('content'); ?>
<div class="row justify-content-center overflow-auto">
    <div class="form-group col-md-9">
            <div class="card">
                <div class="card-header">
                    <h1 style="color: black">
                        <?php echo e($empleados->nombre); ?> <?php echo e($empleados->ap_paterno); ?> <?php echo e($empleados->ap_materno); ?>

                    </h1>
                </div>
                <div class="card-body" style="background-color: #DCDCDC">
                    <form action="<?php echo e(route('empleados.buscarDocumento')); ?>" method="get">
                        <div class="form-group col-md-5  text-muted ">
                            <h2>
                                Datos Personales
                            </h2>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="id">
                                    Numero de Trabajador
                                </label>
                                <label class="form-control" id="id" name="id" type="text">
                                    <?php echo e($empleados->id); ?>

                                </label>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="nombre">
                                    Nombre(s)
                                </label>
                                <label class="form-control" id="nombre" name="nombre" type="text">
                                    <?php echo e($empleados->nombre); ?>

                                </label>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="nombre">
                                    Apellido Paterno
                                </label>
                                <label class="form-control" id="nombre" name="nombre" type="text">
                                    <?php echo e($empleados->ap_paterno); ?>

                                </label>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="nombre">
                                    Apellido Materno
                                </label>
                                <label class="form-control" id="nombre" name="nombre" type="text">
                                    <?php echo e($empleados->ap_materno); ?>

                                </label>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="RFC">
                                    RFC
                                </label>
                                <label class="form-control" id="RFC" name="RFC" type="text">
                                    <?php echo e($empleados->RFC); ?>

                                </label>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="fecha_alta">
                                    Fecha de Alta
                                </label>
                                <label class="form-control" id="fecha_alta" name="fecha_alta" type="text">
                                    <?php echo e(Date::parse($empleados->fecha_alta)->format('j \d\e F \d\e Y')); ?>

                                </label>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="Tcontrato">
                                    Relacion Laboral
                                </label>
                                <label class="form-control" id="Tcontrato" name="Tcontrato" type="text">
                                    <?php if($empleados->Tcontrato=='base'): ?>
                                        PERSONAL DE BASE
                                    <?php elseif($empleados->Tcontrato=='contrato'): ?>
                                        PERSONAL DE CONTRATO
                                    <?php elseif($empleados->Tcontrato=='nombremientoConfianza'): ?>
                                        NOMBRAMIENTO CONFIANZA
                                    <?php elseif($empleados->Tcontrato=='mandosMedios'): ?>
                                        MANDOS MEDIOS
                                    <?php elseif($empleados->Tcontrato=='contratoConfianza'): ?>
                                        CONTRATO CONFIANZA
                                    <?php endif; ?>                                    
                                </label>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="fecha_nombramiento">
                                    Fecha de Nombramiento
                                </label>
                                <label class="form-control" id="fecha_nombramiento" name="fecha_nombramiento" type="text">
                                    <?php if($empleados->fecha_nombramiento==null): ?>
                                        Sin Fecha de Nombramiento
                                    <?php else: ?>
                                    <?php echo e(Date::parse($empleados->fecha_nombramiento)->format('j \d\e F \d\e Y')); ?>

                                    <?php endif; ?>
                                </label>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="telefono">
                                    Telefono
                                </label>
                                <label class="form-control" id="telefono" name="telefono" >
                                    <?php echo e($empleados->telefono); ?>

                                </label>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="genero">
                                    Genero
                                </label>
                                <label class="form-control" id="genero" name="genero" type="text">
                                       <?php echo e($empleados->genero); ?>

                                </label>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="correo">
                                    Correo
                                </label>
                                <label class="form-control" id="correo" name="correo" type="text">
                                    <?php echo e($empleados->correo); ?>

                                </label>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="control-label text-muted" for="puesto">
                                    Categoria
                                </label>
                                <label class="form-control" id="puesto" name="puesto" type="text">
                                    <?php echo e($empleados->puesto); ?>

                                </label>
                            </div>
                            <div class="form-group col-md-4">
                                <label class="control-label text-muted" for="departamento">
                                    Departamento
                                </label>
                                <label class="form-control" id="departamento" name="departamento" type="text">
                                    <?php echo e($empleados->departamento); ?>

                                </label>
                            </div>
                        </div>

                        <div class="form-group col-md-5 text-muted">
                            <h2>
                                Documentos Personales
                            </h2>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-3">
                                <select class="form-control" id="seleccion" name="seleccion">
                                    <?php if($campo==null): ?>
                                    <option selected value="default">Selecciona el Documento</option>
                                    <?php else: ?>
                                    <option value="default">Selecciona el Documento</option>
                                    <?php endif; ?>

                                    <?php if($campo=='contrato'): ?>
                                    <option selected value="contrato">
                                        Contrato
                                    </option>
                                    <?php else: ?>
                                    <option value="contrato">
                                        Contrato
                                    </option>
                                    <?php endif; ?>

                                    <?php if($campo=='creden_elect'): ?>
                                    <option selected value="creden_elect">
                                        Credencial de Elector
                                    </option>
                                    <?php else: ?>
                                    <option value="creden_elect">
                                        Credencial de Elector
                                    </option>
                                    <?php endif; ?>
                                    
                                    <?php if($campo=='acta_nac'): ?>
                                    <option selected value="acta_nac">
                                        Acta de nacimiento
                                    </option>
                                    <?php else: ?>
                                    <option value="acta_nac">
                                        Acta de nacimiento
                                    </option>
                                    <?php endif; ?>

                                    <?php if($campo=='curriculum'): ?>
                                    <option selected value="curriculum">
                                        Curriculum
                                    </option>
                                    <?php else: ?>
                                    <option value="curriculum">
                                        Curriculum
                                    </option>
                                    <?php endif; ?>

                                    <?php if($campo=='solicitud'): ?>
                                    <option selected value="solicitud">
                                        Solicitud de Empleo
                                    </option>
                                    <?php else: ?>
                                    <option value="solicitud">
                                        Solicitud de Empleo
                                    </option>
                                    <?php endif; ?>

                                    <?php if($campo=='cert_medico'): ?>
                                    <option selected value="cert_medico">
                                        Certificado Médico
                                    </option>
                                    <?php else: ?>
                                    <option value="cert_medico">
                                        Certificado Médico
                                    </option>
                                    <?php endif; ?>

                                    <?php if($campo=='cart_recomend'): ?>
                                    <option selected value="cart_recomend">
                                        Carta de Recomendación
                                    </option>
                                    <?php else: ?>
                                    <option value="cart_recomend">
                                        Carta de Recomendación
                                    </option>
                                    <?php endif; ?>

                                    <?php if($campo=='fotografia'): ?>
                                    <option selected value="fotografia">
                                        Fotografia
                                    </option>
                                    <?php else: ?>
                                    <option value="fotografia">
                                        Fotografia
                                    </option>
                                    <?php endif; ?>

                                    <?php if($campo=='const_Noinhab'): ?>
                                    <option selected value="const_Noinhab">
                                        Constancia de No Inhabilitación
                                    </option>
                                    <?php else: ?>
                                    <option value="const_Noinhab">
                                        Constancia de No Inhabilitación
                                    </option>
                                    <?php endif; ?>

                                    <?php if($campo=='comp_Dom'): ?>
                                    <option selected value="comp_Dom">
                                        Comprobante de domicilio
                                    </option>
                                    <?php else: ?>
                                    <option value="comp_Dom">
                                        Comprobante de Domicilio
                                    </option>
                                    <?php endif; ?>

                                    <?php if($campo=='licencia'): ?>
                                    <option selected value="licencia">
                                        Licencia de Conducir
                                    </option>
                                    <?php else: ?>
                                    <option value="licencia">
                                        Licencia de Conducir
                                    </option>
                                    <?php endif; ?>

                                    <?php if($campo=='nss'): ?>
                                    <option selected value="nss">
                                        Numero de Seguro Social
                                    </option>
                                    <?php else: ?>
                                    <option value="nss">
                                        Numero de Seguro Social
                                    </option>
                                    <?php endif; ?>

                                    <?php if($campo=='infonavit'): ?>
                                    <option selected value="infonavit">
                                        Infonavit
                                    </option>
                                    <?php else: ?>
                                    <option value="infonavit">
                                        Infonavit
                                    </option>
                                    <?php endif; ?>

                                    <?php if($campo=='rfc_doc'): ?>
                                    <option selected value="rfc_doc">
                                        Constancia de RFC
                                    </option>
                                    <?php else: ?>
                                    <option value="rfc_doc">
                                        Constancia de RFC
                                    </option>
                                    <?php endif; ?>

                                    <?php if($campo=='cartilla'): ?>
                                    <option selected value="cartilla">
                                        Cartilla Militar Liberada
                                    </option>
                                    <?php else: ?>
                                    <option value="cartilla">
                                        Cartilla Militar Liberada
                                    </option>
                                    <?php endif; ?>

                                    <?php if($campo=='curp'): ?>
                                    <option selected value="curp">
                                        Clave Única de Registro de Poblacional (CURP)
                                    </option>
                                    <?php else: ?>
                                    <option value="curp">
                                        Clave Única de Registro de Poblacional (CURP)
                                    </option>
                                    <?php endif; ?>

                                    <?php if($campo=='diploma'): ?>
                                    <option selected value="diploma">
                                        Diploma de Grado de Estudio
                                    </option>
                                    <?php else: ?>
                                    <option value="diploma">
                                        Diploma de Grado de Estudio
                                    </option>
                                    <?php endif; ?>

                                    <?php if($campo=='nombramiento'): ?>
                                    <option selected value="nombramiento">
                                        Nombramiento
                                    </option>
                                    <?php else: ?>
                                    <option value="nombramiento">
                                        Nombramiento
                                    </option>
                                    <?php endif; ?>

                                    <?php if($campo=='dictamen'): ?>
                                    <option selected value="dictamen">
                                        Dictamen
                                    </option>
                                    <?php else: ?>
                                    <option value="dictamen">
                                        Dictamen
                                    </option>
                                    <?php endif; ?>

                                    
                                </select>
                            </div>
                            <div class="form-group col-md-3"> 
                                    <button class="btn btn-primary float-left" name = "idF"  type="submit" value=<?php echo e($empleados->id); ?>>
                                        <i class="fas fa-search"></i>
                                        Buscar
                                    </button>
                            </div>
                        </div> 
                    </form>
                    <?php if($seleccion!=null): ?>
                    <center>
                        <iframe class="iframe hidden-print" for="seleccion" src=<?php echo e($seleccion); ?>></iframe>
                    </center>
                    <?php elseif($campo=='default'): ?>
                        <h2 class="alert alert-primary" role="alert" style="color:black">Selecciona un Documento</h2>
                    <?php elseif($seleccion==null): ?>
                        <h2 div class="alert alert-danger" role="alert" style="color:black">No se cuenta con el archivo seleccionado</h2>
                    <?php endif; ?>

                    <br>
                    <div class="form-group col-md-5 text-muted">
                        <h5>
                            Documentos Personales Adicionales
                        </h5>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-3">
                        <form action="<?php echo e(route('empleados.buscarDocumentoAdicional')); ?>" method="get">
                            <select class="form-control" id="select" name="select">
                                <option value="default">Selecciona el Documento</option>
                                <?php $__currentLoopData = $adicionales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adicional): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($adicional->dir); ?>">
                                        <?php echo e($adicional->nombre); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select> 
                        </div>
                        <div class="form-group col-md-3"> 
                            <button class="btn btn-primary float-left" name="adi"  type="submit" value=<?php echo e($empleados->id); ?>>
                                <i class="fas fa-search"></i>
                                    Buscar
                            </button>
                        </div>
                        </form>
                    </div>
                    <?php if($nombre!=null): ?>
                    <label class="form-control" id="name" name="name" type="text">
                        <?php echo e($nombre); ?>

                    </label>
                    <?php endif; ?>

                    <?php if($extra=='default'): ?>
                        <h2 class="alert alert-primary" role="alert" style="color:black">Selecciona un Documento</h2>
                    <?php elseif($extra!=null): ?>
                    <center>
                        <iframe class="iframe hidden-print" for="seleccion" src="<?php echo e($extra); ?>"></iframe>
                    </center>
                    <?php endif; ?>
                </div>
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CEVI2.0\resources\views/Empleados/showEmpleado.blade.php ENDPATH**/ ?>