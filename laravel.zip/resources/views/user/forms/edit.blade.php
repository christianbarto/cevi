<div aria-hidden="true" aria-labelledby="exampleModalLabel" class="modal fade" id="EditUsuario" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button class="close" data-dismiss="modal" type="button">
                  <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                ...
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">
                    Close
                </button>
                <button class="btn btn-primary" type="button">
                    Save changes
                </button>
            </div>
        </div>
    </div>
</div>
